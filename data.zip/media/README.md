This folder is only used for storing Media assets. You do not need this folder for running Hygieia℠.
