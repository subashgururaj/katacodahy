The README is in the [gh-pages](https://github.com/capitalone/Hygieia/blob/gh-pages/pages/hygieia/UI-tests/UI-tests.md) branch. Please update it there.
