This document is in the [gh-pages](https://github.com/capitalone/Hygieia/blob/gh-pages/pages/hygieia/setup.md) branch. Please update it there.
